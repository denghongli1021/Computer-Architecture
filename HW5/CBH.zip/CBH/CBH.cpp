#include<iostream>

using namespace std;
//Reference: https://www.geeksforgeeks.org/how-to-check-if-a-given-array-represents-a-binary-heap/?ref=lbp

//===============testcase1=======================
int arr[] = {32, 16, 12, 15, 9, 10, 1};
int n = 7;
//output: True
//================================================

//===============testcase2========================
// int arr[] = {18, 6, 12, 9, 1};
// int n = 5;
//output: False
//================================================

// Returns true if arr[i..n-1] represents a max-heap 
bool isHeap(int arr[], int i, int n) 
{ 
    // return if reach leaf node
    if (i * 2 + 1 >= n) 
        return true; 
  
    // If an internal node and is greater than its children, 
    // and same is recursively true for the children 
    if (arr[i] >= arr[i * 2 + 1] && arr[i] >= arr[i * 2 + 2] &&
        isHeap(arr, i * 2 + 1, n) &&
        isHeap(arr, i * 2 + 2, n))
        return true; 
  
    return false; 
} 

int main() 
{   
    if (isHeap(arr, 0, n))
        cout << "True";
    else
        cout << "False"; 
  
    return 0; 
}
